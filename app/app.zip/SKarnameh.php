<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SKarnameh extends Model
{
    protected $guarded = [];

}
