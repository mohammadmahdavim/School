<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MainPage extends Model
{
    protected $guarded = [

    ];
}
