<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RollCallMoshaver extends Model
{
    protected $guarded=[];
}
