<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FirstMessage extends Model
{
    protected $guarded=[];
}
