<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class paye extends Model
{
    protected $guarded = [];

}
