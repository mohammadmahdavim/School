<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PasokhTeacher extends Model
{
    protected $guarded = [];
}
