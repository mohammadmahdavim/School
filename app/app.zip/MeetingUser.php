<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MeetingUser extends Model
{
    //
}
