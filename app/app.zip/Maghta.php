<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Maghta extends Model
{
    public $timestamps = false;

    protected $guarded=[];
    protected $table='maghta';
}
